# stroop_effect

Projet de mesures comportementales basé sur les travaux de recherches de l'effet Stroop :
"Early and late indications of item-specificcontrol in a Stroop mouse tracking study"

Etudiants :
Ruffieux Mathis et Dugaleix Nereis
Année 2021/2022
